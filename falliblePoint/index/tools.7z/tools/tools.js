/**
 * 常用方法
 * @namespace
 */
window.tools = {};

(function () {
    'use strict';

    /**
     * 判断一个对象是否是数组
     * @param {object} o 待判断对象
     * @returns {boolean} 判断是否为数组对象
     */
    tools.isArray = function (o) {
        return Object.prototype.toString.call(o) === '[object Array]';
    };
    /**
     * 判断数组里是否包含该元素
     * @array {object} 数组
     * @item {object} 元素
     * @returns {boolean} 判断是否为数组对象
     */
    tools.IfArrayContainElement = function (array, item) {
        for (var i = 0; i < array.length; i++) {
            if (array[i] == item) {
                return true;
            }
        }
        return false;
    };
    /**
     * 返回对象数组id的下标
     * @array {ObjectArray} 对象数组
     * @item {name} 元素
     * @returns {string} 数组下标
     */
    tools.indexOfArray = function (ObjectArray, name) {
        for (var i = 0; i < ObjectArray.length; i++) {
            if (ObjectArray[i].Id == name) {
                return i;
            }
        }
    };
    /**
     * 金额由元转为分
     * @string {data} 金额
     * @string {data} 转换后的金额
     */
    tools.YUANTOFENCheck = function (data) {
        if (data == '' || typeof data == 'undefined') {
            return '';
        }
        var checkdata = data.split('.');
        if (checkdata[1] == '' || checkdata[1] == null) {
            checkdata = checkdata[0] + '00';
        } else if (checkdata[1].length == '1') {
            checkdata = checkdata[0] + checkdata[1] + '0';
        } else {
            checkdata = checkdata[0] + checkdata[1];
        }
        return checkdata;
    };

    /**
     * added by zk at 2019/04/19
     * 返回间隔几月的日期，需要计算当月日期，不能直接设置日期对象的天数
     * 180天 != 半年
     * @param {String} date 日期 2019/04/19
     * @param {Number} intervalMon 间隔月份，正数代表查找之后月份的日期，负数代表之前月份日期
     * @param {String} separator 分隔符 默认是 "/"
     * @return {String} 间隔月数后的日期字符串
     */
    tools.getIntervalMonsDate = function (date, intervalMon, separator) {
        separator = separator ? separator : "/";
        // 根据字符串日期获取日期对象
        var curDate = tools.formatStringToDate(date, separator);

        var curYear = curDate.getFullYear(), // 当年
            curMon = curDate.getMonth() + 1, // 获取当月
            curDay = curDate.getDate(); // 当天

        var _year = curYear,
            _month = curMon + intervalMon,
            _day = curDay;

        if (_month > 12) {
            // 跨年获取之后的月份
            var intervalYear = _month % 12 == 0 ? parseInt(_month / 12) + 1 : Math.floor(_month / 12); // 获取间隔的年份
            _year = curYear + intervalYear; // 转换后的年份
            _month = _month - intervalYear * 12; // 转换后的月份
        } else if (_month < 1) {
            // 跨年获取之前的月份
            var intervalYear = -_month % 12 == 0 ? parseInt(-_month / 12) + 1 : Math.ceil(-_month / 12); // 获取间隔的年份
            _year = curYear - intervalYear; // 转换后的年份
            _month = _month + intervalYear * 12; // 转换后的月份
        }

        var curMonDayNum = tools.getCurMonDayNum(tools.formatStringToDate(_year + separator + _month + separator + "01", separator)); // 获取前一月天数
        // 当前天数大于上一月最大天数，取上一月最大天数
        _day = curDay > curMonDayNum ? curMonDayNum : curDay;

        return "" + _year + separator + tools.formatLessThanTenNum(_month) + separator + tools.formatLessThanTenNum(_day);
    };


    tools.formatStringToDate = function (date, separator) {
        separator = separator ? separator : "/";
        var dateArr = date.split(separator);
        if (dateArr.length < 3) {
            console.log(date + " not conforming to format");
            return false;
        }

        return new Date(dateArr[0], Number(dateArr[1]) - 1, dateArr[2]);
    };

    /**
     * added by zk at 2019/04/19
     * 获取当月天数
     * @param {Date} date 日期对象
     * @param {String} separator 分隔符，默认为 "/"
     * @return {Number} 当月天数
     */
    tools.getCurMonDayNum = function (date) {
        var year = date.getFullYear(),
            month = date.getMonth(); // 当前月 - 1
        var daysNum = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        if (tools.isLeapYear(year)) {
            daysNum[1] = 29;
        }
        return daysNum[month];
    };
    /**
     * added by zk at 2019/04/19
     * 格式化小于10的整数，前面补0
     * 未考虑大于100的数字及负数
     * @param {String | Number} 需要格式化的数字
     * @return {String} 格式化后的字符串
     */
    tools.formatLessThanTenNum = function (num) {
        return num < 10 ? "0" + Number(num) : "" + num;
    };

    /**
     * added by zk at 2019/04/19
     * 判断是否是闰年
     * @param {String} year 年份
     * @return {Boolean} 是闰年时返回true
     */
    tools.isLeapYear = function (year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 100 == 0 && year % 400 == 0);
    };
    /**
     * 判断一个字符串是否在一个以‘,‘分割的字符串中，判断不区分大小写
     * 如：tools.hasKeyInString('F1', 'F1, F2, F11, F10') 将返回true
     * 压缩精简后可能返回1，判断bool返回值时请用 if (flag) {}来进行
     * @param {string} key 要搜索的字符串
     * @param {string} string 被搜索的字符串
     * @returns {boolean} 判断是否存在
     */
    tools.hasKeyInString = function (key, string) {
        if (key == '' || key == undefined || string == '') {
            return false;
        } else {
            return (',' + string.replace(' ', '') + ',').toUpperCase().indexOf(',' + key.toUpperCase() + ',') == -1 ? false : true;
        }
    };

    /**
     * 生成一个随机数，范围为Number类型可表达的最大范围，随机范围非常大
     * @returns {string} 不含小数点的Number变量
     */
    tools.newRnd = function () {
        return (Number.MAX_VALUE * Math.random()).toFixed();
    };

    /**
     * 判断一个文件完整路径是否存在，暂不支持相对路径
     * 暂不支持http方式，避免异步调用
     * @param {string} filePath 文件路径
     * @returns {boolean} 存在情况
     * @private
     */
    tools.hasFilePath = function (filePath) {
        return true;
    };

    /**
     * 格式化金额，等同FormatNumber，例如1200转换为1,200.00
     * @author xialiu at 2014-11-12
     * @param {string} amount 要转换的金额
     * @param {string} n 小数字点后保存的位数
     * @returns {string} 转换后的金额数据
     */
    tools.conAmountFormatNumber = function (amount, n) {
        if (amount === '' || amount == undefined) {
            return '';
        } else if (amount == 0 || amount == '0') {
            return '0.00';
        }
        amount = amount.toString();
        n = n > 0 && n <= 20 ? n : 2;
        amount = parseFloat((amount + '').replace(/[^\d\.-]/g, '')).toFixed(n) + '';
        var l = amount
                .split('.')[0]
                .split('')
                .reverse(),
            r = amount.split('.')[1];
        var newamount, t, i;
        t = '';
        for (i = 0; i < l.length; i++) {
            t += l[i] + ((i + 1) % 3 == 0 && i + 1 != l.length ? ',' : '');
        }
        newamount =
            t
                .split('')
                .reverse()
                .join('') +
            '.' +
            r;

        if (newamount.slice(0, 1) == '+' || newamount.slice(0, 1) == '-') {
            if (newamount.slice(1, 2) == ',') {
                newamount = newamount.slice(0, 1).toString() + newamount.slice(-(newamount.length - 2)).toString();
            }
        }
        return newamount;
    };

    /**
     * 数据按传入的分隔符与位数进行分隔与填充处理
     * @author xialiu at 2014-11-12
     * @param {string} sour 要转换的数据
     * @param {string} charCode 要填充的数据
     * @param {string} len 分隔的位数
     * @returns {string} 转换后的数据
     */
    tools.conDatawithSignAndnum = function (sour, charCode, len) {
        var dest = '';
        for (var i = 0; i < sour.length; i++) {
            if (i != 0 && i % len == 0) {
                dest = dest + charCode + sour.charAt(i);
            } else {
                dest = dest + sour.charAt(i);
            }
        }
        return dest;
    };

    /**
     * 数据转换分至元
     * @author xialiu at 2015-8-18
     * @param {string} sour 要转换的数据
     * @returns {string} 转换后的数据
     */
    tools.conDataToRealAmount = function (sour) {
        if (sour === '' || sour == undefined) {
            return '';
        }
        if (sour == 0) {
            return '0';
        }
        var dest = '';
        var str = '';
        var intSum = 0;
        var dot = 0;
        str = (sour / 100).toFixed(2) + '';
        intSum = str.substring(0, str.indexOf('.')).replace(/\B(?=(?:\d{3})+$)/g, ','); //取到整数部分
        dot = str.substring(str.length, str.indexOf('.')); //取到小数部分
        dest = intSum + dot;
        return dest;
    };

    /**
     * 数据转换金额大写
     * @author xialiu at 2015-8-18
     * @param {string} sour 要转换的数据，传入数据格式为1000（表示壹仟元），最大范围为仟亿
     * @returns {string} 转换后的数据
     */
    tools.conDataToCapital = function (sour) {
        if (sour == '' || sour == undefined) {
            return '';
        }
        var dest = '';
        var strUnit = '仟佰拾亿仟佰拾万仟佰拾元角分';
        sour += '00';
        var intPos = sour.indexOf('.');
        if (intPos >= 0) sour = sour.substring(0, intPos) + sour.substr(intPos + 1, 2);
        strUnit = strUnit.substr(strUnit.length - sour.length);
        for (var i = 0; i < sour.length; i++) dest += '零壹贰叁肆伍陆柒捌玖'.substr(sour.substr(i, 1), 1) + strUnit.substr(i, 1);
        dest = dest
            .replace(/零角零分$/, '')
            .replace(/零[仟佰拾]/g, '零')
            .replace(/零{2,}/g, '零')
            .replace(/零([亿|万])/g, '$1')
            .replace(/零+元/, '元')
            .replace(/亿零{0,3}万/, '亿')
            .replace(/^元/, '零元');
        return dest;
    };

    /**
     * n位一分转换账号数据
     * @param {string} account 要转换的账号
     * @param {string} delimiter 添加的分隔符
     * @param {number} num 多少位一分隔
     * @returns {string} 转换后的账号数据
     */
    tools.convAccountData = function (account, delimiter, num) {
        var newAccount = '';
        while (account) {
            newAccount += account.slice(0, num) + delimiter;
            account = account.slice(num);
        }
        newAccount = newAccount.slice(0, -1);
        return newAccount;
    };

    /**
     * 隐藏账号数据
     * @author wangzunjie at 2017-7-13
     * @param {string} account 要转换的账号
     * @param {number} preLen 保留账号前几位
     * @param {number} tailLen 保留账号后几位
     * @param {string} filler 填充字符
     * @param {number} fillLen 填充长度
     * @returns {string} 转换后的账号数据
     */
    tools.hideAccountData = function (account, preLen, tailLen, filler, fillLen) {
        var newAccount = '';
        if (account.length >= preLen + tailLen) {
            newAccount += account.slice(0, preLen);
            while (fillLen > 0) {
                newAccount += filler;
                fillLen--;
            }
            newAccount += account.slice(-tailLen);
        }
        return newAccount;
    };

    /**
     * 隐藏账号尾数
     * @author wangzunjie at 2017-7-13
     * @param {string} account 要转换的账号
     * @param {number} preLen 隐藏账号从倒数第几位开始
     * @param {number} tailLen 隐藏账号到倒数第几位结束
     * @param {string} filler 填充字符
     * @returns {string} 转换后的账号数据
     */
    tools.hideTailAccountData = function (account, preLen, tailLen, filler) {
        var newAccount = '';
        if (account.length >= preLen) {
            newAccount += account.slice(0, account.length - preLen);
            var fillLen = preLen - tailLen;
            while (fillLen > 0) {
                newAccount += filler;
                fillLen--;
            }
            newAccount += account.slice(-tailLen);
        }
        return newAccount;
    };

    /**
     * 隐藏名字中的姓氏数据
     * @author wangzunjie at 2017-7-13
     * @param {string} name 要转换的姓名
     * @param {string} filler 填充字符
     * @returns {string} 转换后的账号数据
     */
    tools.hideLastName = function (name, filler) {
        var newName = filler;
        if (name.length > 0) {
            newName += name.slice(1);
        }
        return newName;
    };

    /**
     * 两个数字相加 (高精度)
     * @param {string/number} data1、data2 需要相加的两个数字
     * @returns {number} 相加后的两个数字之和
     */
    tools.add = function (data1, data2) {
        var data = new BigNumber(tools.strToNum(data1)), addData = new BigNumber(tools.strToNum(data2));
        return data.plus(addData).toNumber();
    };

    /**
     * 两个数字相减 (高精度)
     * @param {string/number} data1、data2 需要相减的两个数字
     * @returns {number} data1减data2后的计算结果
     */
    tools.subtract = function (data1, data2) {
        var data = new BigNumber(tools.strToNum(data1)), minusData = new BigNumber(tools.strToNum(data2));
        return data.minus(minusData).toNumber();
    };

    /**
     * 两个数字相乘 (高精度)
     * @param {string/number} data1、data2 需要相乘的两个数字
     * @returns {number} data1乘data2后的计算结果
     */
    tools.multiply = function (data1, data2) {
        var data = new BigNumber(tools.strToNum(data1)), multiplyData = new BigNumber(tools.strToNum(data2));
        return data.multipliedBy(multiplyData).toNumber();
    };
    /**
     * 两个数字相除 (高精度)
     * @param {string/number} data1、data2 需要相除的两个数字
     * @returns {number} data1除以data2后的计算结果
     */
    tools.divide = function (data1, data2) {
        var data = new BigNumber(tools.strToNum(data1)), divData = new BigNumber(tools.strToNum(data2));
        if (divData == 0) {
            return 0;
        } else {
            return data.div(divData).toNumber();
        }
    };
    /**
     * 字符串转数字（若不是数字返回0）
     * @param {string} data1 要转换的字符串
     * @returns {number} 字符串转数字
     */
    tools.strToNum = function (data1, ErrorInfo) {
        if (typeof (ErrorInfo) == "undefined") {
            ErrorInfo = 0;
        }
        if (data1 == "" || typeof (data1) == "undefined") {
            return ErrorInfo;
        } else if (typeof (data1) != "number") {
            if (!Mtils.validation.isNumber(data1)) {
                return ErrorInfo;
            } else {
                return parseFloat(data1);
            }
        } else
            return data1;
    }

    /**
     * 格式化日期时间 Add By 刘召
     * @param datetime 需要进行格式化的日期时间数据，pattern日期格式 yyyy/MM/dd hh:mm:ss
     * @returns {string} 格式化后的日期、时间
     */
    tools.DateTimeFormat = function (timestamp, pattern) {
        if (timestamp == null || typeof (timestamp) == "undefined") {
            return '';
        }
        timestamp = (timestamp.toString()).replace(/\s*/g, '');
        if (!Mtils.validation.isInteger(timestamp)) {
            return timestamp;
        }
        var tmp = new Date();
        if (timestamp.length == 14) {
            if (typeof pattern == "undefined" || pattern == "" || pattern == null) {
                pattern = "yyyy-MM-dd hh:mm:ss";
            }
            tmp.setFullYear(timestamp.substring(0, 4));
            tmp.setMonth(parseInt(timestamp.substring(4, 6)) - 1, parseInt(timestamp.substring(6, 8)));
            // tmp.setDate(timestamp.substring(6, 8));
            tmp.setHours(timestamp.substring(8, 10));
            tmp.setMinutes(timestamp.substring(10, 12));
            tmp.setSeconds(timestamp.slice(-2));
        } else if (timestamp.length == 8) {
            if (typeof pattern == "undefined" || pattern == "" || pattern == null) {
                pattern = "yyyy-MM-dd";
            }
            tmp.setFullYear(timestamp.substring(0, 4));
            tmp.setMonth(parseInt(timestamp.substring(4, 6)) - 1, parseInt(timestamp.substring(6, 8)));
            //tmp.setDate(timestamp.substring(6, 8));
        } else if (timestamp.length == 6) {
            if (typeof pattern == "undefined" || pattern == "" || pattern == null) {
                pattern = "hh:mm:ss";
            }
            tmp.setHours(timestamp.substring(0, 2));
            tmp.setMinutes(timestamp.substring(2, 4));
            tmp.setSeconds(timestamp.slice(-2));
        } else {
            if (typeof pattern == "undefined" || pattern == "" || pattern == null) {
                pattern = "yyyy-MM-dd hh:mm:ss";
            }
        }
        var o = {
            "M+": tmp.getMonth() + 1, //month
            "d+": tmp.getDate(), //day
            "h+": tmp.getHours(), //hour
            "m+": tmp.getMinutes(), //minute
            "s+": tmp.getSeconds(), //second
            "q+": Math.floor((tmp.getMonth() + 3) / 3), //quarter
            "S": tmp.getMilliseconds() //millisecond
        }
        if (/(y+)/.test(pattern)) {
            pattern = pattern.replace(RegExp.$1, (tmp.getFullYear() + "").substr(4 - RegExp.$1.length));
        }

        for (var k in o) {
            if (new RegExp("(" + k + ")").test(pattern)) {
                pattern = pattern.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
            }
        }
        return pattern;
    };


    /**
     * JSON串组包工具函数
     * @param {string} JSONstr 需要组JSON串的数据，格式为 "路径,value|"
     * @returns {Object} 组号后的JSON串对象
     */
    tools.packJSON = function (JSONstr) {
        var arrJSON = JSONstr.split('|');
        var sendJSONstr = '{"messagetype":"","messageinfo":{"infotype":""}}';
        var sendJSONobj = JSON.parse(sendJSONstr);
        for (var i = 0; i < arrJSON.length; i++) {
            var arrJSONNameValue = arrJSON[i].split(',');
            if (arrJSONNameValue[0] != '') {
                var JSONRoute = arrJSONNameValue[0].split('.');
                switch (JSONRoute.length) {
                    case 1:
                        sendJSONobj[JSONRoute[0]] = arrJSONNameValue[1];
                        break;
                    case 2:
                        if (sendJSONobj[JSONRoute[0]] == undefined) {
                            sendJSONobj[JSONRoute[0]] = {};
                        }
                        sendJSONobj[JSONRoute[0]][JSONRoute[1]] = arrJSONNameValue[1];
                        break;
                    case 3:
                        if (sendJSONobj[JSONRoute[0]] == undefined) {
                            sendJSONobj[JSONRoute[0]] = {};
                        }
                        if (sendJSONobj[JSONRoute[0]][JSONRoute[1]] == undefined) {
                            sendJSONobj[JSONRoute[0]][JSONRoute[1]] = {};
                        }
                        sendJSONobj[JSONRoute[0]][JSONRoute[1]][JSONRoute[2]] = arrJSONNameValue[1];
                        break;
                    case 4:
                        if (sendJSONobj[JSONRoute[0]] == undefined) {
                            sendJSONobj[JSONRoute[0]] = {};
                        }
                        if (sendJSONobj[JSONRoute[0]][JSONRoute[1]] == undefined) {
                            sendJSONobj[JSONRoute[0]][JSONRoute[1]] = {};
                        }
                        if (sendJSONobj[JSONRoute[0]][JSONRoute[1]][JSONRoute[2]] == undefined) {
                            sendJSONobj[JSONRoute[0]][JSONRoute[1]][JSONRoute[2]] = {};
                        }
                        sendJSONobj[JSONRoute[0]][JSONRoute[1]][JSONRoute[2]][JSONRoute[3]] = arrJSONNameValue[1];
                        break;
                    default:
                        break;
                }
            }
        }
        return sendJSONobj;
    };

    /**
     * 获取JSON串个数工具函数
     * @param {json} strJSON 需要计算节点个数的JSON串数据
     * @returns {number} JSON子节点个数
     */
    tools.getJSONLength = function (strJSON) {
        var length = 0;
        for (var item in strJSON) {
            length++;
        }
        return length;
    };

    /**
     * 删除字符串头尾空格
     * @param {string} str 需要删除空格的字符串
     * @returns {string} 删除空格后的字符串
     */
    tools.trim = function (str) {
        if (str == '' || str == undefined) {
            return '';
        } else {
            return str.replace(/(^\s*)|(\s*$)/g, '');
        }
    };

    /**
     * 校验IP格式
     * @param {string} strIp 需要进行校验的字符串
     * @returns {boolean} 校验结果
     */
    tools.checkIPFormat = function (strIp) {
        var re = /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/; //正则表达式
        if (re.test(strIp)) {
            if (RegExp.$1 < 256 && RegExp.$2 < 256 && RegExp.$3 < 256 && RegExp.$4 < 256) return true;
        }
        return false;
    };

    /**
     * 判断字符串是否日期格式，字符串YYYYMMDD
     * @param {string} strDate 需要判断的字符串格式
     * @returns {boolean} 判断结果
     */
    tools.IsDate = function (strDate) {
        if (strDate.length != 8) {
            return false;
        }
        var nYear = parseInt(strDate.substr(0, 4), 10);
        var nMonth = parseInt(strDate.substr(4, 2), 10);
        var nDay = parseInt(strDate.substr(6, 2), 10);
        var d = new Date(nYear, nMonth - 1, nDay);
        return d.getFullYear() == nYear && d.getMonth() + 1 == nMonth && d.getDate() == nDay;
    };

    /**
     * 格式化手机号码，格式为：133 6666 6666
     * @param phoneNum 需要进行格式化的手机号码
     * @returns {string} 格式化后的手机号码
     */
    tools.phoneNumFormat = function (phoneNum) {
        var strPhoneNum;
        if (phoneNum.length > 3) {
            strPhoneNum = phoneNum.slice(0, 3) + ' ';
            phoneNum = phoneNum.slice(3);
            while (phoneNum) {
                strPhoneNum = strPhoneNum + phoneNum.slice(0, 4) + ' ';
                phoneNum = phoneNum.slice(4);
            }
            strPhoneNum = strPhoneNum.slice(0, -1);
            return strPhoneNum;
        } else {
            return phoneNum;
        }
    };

    /**
     * 获取当前浏览器版本
     * @author wangzunjie at 2017-10-10
     * @returns {string} 浏览器版本
     */
    tools.getCurrentBrowser = function () {
        var userAgent = navigator.userAgent; // 取得浏览器的userAgent字符串
        if (userAgent.toUpperCase().indexOf('FIREFOX') > -1) {
            return 'FF';
        } else if (userAgent.toUpperCase().indexOf('CHROME') > -1) {
            return 'Chrome';
        } else if (userAgent.toUpperCase().indexOf('SAFARI') > -1) {
            return 'Safari';
        } else if (userAgent.toUpperCase().indexOf('COMPATIBLE') > -1 && userAgent.toUpperCase().indexOf('MSIE') > -1 && userAgent.indexOf('10.0') > -1) {
            return 'IE10';
        } else if (userAgent.toUpperCase().indexOf('TRIDENT') > -1 && userAgent.toUpperCase().indexOf('RV:11.0') > -1) {
            return 'IE11';
        } else if (userAgent.toUpperCase().indexOf('COMPATIBLE') > -1 && userAgent.toUpperCase().indexOf('MSIE') > -1) {
            return 'IE';
        } else {
            return 'Other';
        }
    };
    tools.getVW = function (num) {
        return tools.divide(num, document.documentElement.clientWidth) * 100;
    }
})();
